import pandas as pd

# Load dataset
df = pd.read_csv("data/marketing-campaigns-1000.csv")

# -----------------------------------
# 1. BASIC INFORMATION
# -----------------------------------

print("\nDATASET SHAPE:")
print(df.shape)

print("\nCOLUMNS:")
print(df.columns.tolist())

# -----------------------------------
# 2. CONVERT DATE
# -----------------------------------

df["date"] = pd.to_datetime(df["date"])

print("\nDATE RANGE:")
print(df["date"].min())
print(df["date"].max())

# -----------------------------------
# 3. CHECK MISSING VALUES
# -----------------------------------

print("\nMISSING VALUES:")
print(df.isnull().sum())

# -----------------------------------
# 4. CHECK DUPLICATES
# -----------------------------------

print("\nDUPLICATE ROWS:")
print(df.duplicated().sum())

# -----------------------------------
# 5. CHECK UNIQUE CAMPAIGNS
# -----------------------------------

print("\nNUMBER OF CAMPAIGNS:")
print(df["campaign"].nunique())

print("\nCAMPAIGNS:")
print(df["campaign"].unique())

# -----------------------------------
# 6. CHECK CHANNELS
# -----------------------------------

print("\nCHANNELS:")
print(df["channel"].value_counts())

# -----------------------------------
# 7. CHECK NUMERIC VALUES
# -----------------------------------

print("\nNEGATIVE VALUES:")
print((df[["impressions", "clicks", "spend", "conversions", "revenue"]] < 0).sum())
# -----------------------------------
# 8. CALCULATE MARKETING KPIs
# -----------------------------------

# Click Through Rate
df["CTR"] = (df["clicks"] / df["impressions"]) * 100

# Cost Per Click
df["CPC"] = df["spend"] / df["clicks"]

# Conversion Rate
df["Conversion_Rate"] = (df["conversions"] / df["clicks"]) * 100

# Cost Per Acquisition
df["CPA"] = df["spend"] / df["conversions"].replace(0, pd.NA)

# Return on Ad Spend
df["ROAS"] = df["revenue"] / df["spend"]

# Display KPI results
print("\nKPI SUMMARY:")
print(df[[
    "CTR",
    "CPC",
    "Conversion_Rate",
    "CPA",
    "ROAS"
]].describe())
# -----------------------------------
# 9. CHANNEL PERFORMANCE ANALYSIS
# -----------------------------------

channel_performance = df.groupby("channel").agg({
    "impressions": "sum",
    "clicks": "sum",
    "spend": "sum",
    "conversions": "sum",
    "revenue": "sum"
}).reset_index()

# Calculate channel-level KPIs
channel_performance["CTR"] = (
    channel_performance["clicks"] /
    channel_performance["impressions"]
) * 100

channel_performance["CPC"] = (
    channel_performance["spend"] /
    channel_performance["clicks"]
)

channel_performance["Conversion_Rate"] = (
    channel_performance["conversions"] /
    channel_performance["clicks"]
) * 100

channel_performance["CPA"] = (
    channel_performance["spend"] /
    channel_performance["conversions"]
)

channel_performance["ROAS"] = (
    channel_performance["revenue"] /
    channel_performance["spend"]
)

print("\nCHANNEL PERFORMANCE:")
print(channel_performance.round(2))
# -----------------------------------
# 10. CAMPAIGN PERFORMANCE ANALYSIS
# -----------------------------------

campaign_performance = df.groupby("campaign").agg({
    "impressions": "sum",
    "clicks": "sum",
    "spend": "sum",
    "conversions": "sum",
    "revenue": "sum"
}).reset_index()

# Calculate KPIs
campaign_performance["CTR"] = (
    campaign_performance["clicks"] /
    campaign_performance["impressions"]
) * 100

campaign_performance["CPC"] = (
    campaign_performance["spend"] /
    campaign_performance["clicks"]
)

campaign_performance["Conversion_Rate"] = (
    campaign_performance["conversions"] /
    campaign_performance["clicks"]
) * 100

campaign_performance["CPA"] = (
    campaign_performance["spend"] /
    campaign_performance["conversions"]
)

campaign_performance["ROAS"] = (
    campaign_performance["revenue"] /
    campaign_performance["spend"]
)

# Sort by ROAS
campaign_performance = campaign_performance.sort_values(
    by="ROAS",
    ascending=False
)

print("\nCAMPAIGN PERFORMANCE:")
print(campaign_performance.round(2).to_string(index=False))
# -----------------------------------
# 11. MONTHLY PERFORMANCE ANALYSIS
# -----------------------------------

# Create month column
df["month"] = df["date"].dt.to_period("M").astype(str)

monthly_performance = df.groupby("month").agg({
    "spend": "sum",
    "revenue": "sum",
    "conversions": "sum",
    "clicks": "sum",
    "impressions": "sum"
}).reset_index()

# Calculate monthly KPIs
monthly_performance["CTR"] = (
    monthly_performance["clicks"] /
    monthly_performance["impressions"]
) * 100

monthly_performance["Conversion_Rate"] = (
    monthly_performance["conversions"] /
    monthly_performance["clicks"]
) * 100

monthly_performance["ROAS"] = (
    monthly_performance["revenue"] /
    monthly_performance["spend"]
)

monthly_performance["CPA"] = (
    monthly_performance["spend"] /
    monthly_performance["conversions"]
)

print("\nMONTHLY PERFORMANCE:")
print(monthly_performance.round(2).to_string(index=False))
# -----------------------------------
# 12. MONTHLY REVENUE TREND
# -----------------------------------

import matplotlib.pyplot as plt

plt.figure(figsize=(12, 6))

plt.plot(
    monthly_performance["month"],
    monthly_performance["revenue"],
    marker="o"
)

plt.title("Monthly Marketing Revenue")
plt.xlabel("Month")
plt.ylabel("Revenue")
plt.xticks(rotation=45)
plt.grid(True)

plt.tight_layout()
plt.show()
# -----------------------------------
# 13. CHANNEL ROAS
# -----------------------------------

plt.figure(figsize=(10, 6))

plt.bar(
    channel_performance["channel"],
    channel_performance["ROAS"]
)

plt.title("ROAS by Marketing Channel")
plt.xlabel("Marketing Channel")
plt.ylabel("ROAS (Revenue / Spend)")
plt.xticks(rotation=30)

plt.tight_layout()
plt.show()
# -----------------------------------
# 14. CAMPAIGN ROAS
# -----------------------------------

campaign_roas = campaign_performance.sort_values(
    by="ROAS",
    ascending=True
)

plt.figure(figsize=(10, 7))

plt.barh(
    campaign_roas["campaign"],
    campaign_roas["ROAS"]
)

plt.title("ROAS by Marketing Campaign")
plt.xlabel("ROAS (Revenue / Spend)")
plt.ylabel("Campaign")

plt.tight_layout()
plt.show()
# -----------------------------------
# 15. MARKETING FUNNEL ANALYSIS
# -----------------------------------

total_impressions = df["impressions"].sum()
total_clicks = df["clicks"].sum()
total_conversions = df["conversions"].sum()

click_rate = (total_clicks / total_impressions) * 100
conversion_rate = (total_conversions / total_clicks) * 100

print("\nMARKETING FUNNEL:")
print(f"Total Impressions: {total_impressions:,}")
print(f"Total Clicks: {total_clicks:,}")
print(f"Total Conversions: {total_conversions:,}")

print(f"\nImpression → Click Rate: {click_rate:.2f}%")
print(f"Click → Conversion Rate: {conversion_rate:.2f}%")
# -----------------------------------
# 16. CHANNEL INVESTMENT ANALYSIS
# -----------------------------------

# Calculate median benchmarks
median_roas = channel_performance["ROAS"].median()
median_conversion = channel_performance["Conversion_Rate"].median()

print("\nCHANNEL BENCHMARKS:")
print(f"Median ROAS: {median_roas:.2f}")
print(f"Median Conversion Rate: {median_conversion:.2f}%")

# Classify channels
def classify_channel(row):
    if (
        row["ROAS"] >= median_roas
        and row["Conversion_Rate"] >= median_conversion
    ):
        return "Scale"

    elif (
        row["ROAS"] >= median_roas
        or row["Conversion_Rate"] >= median_conversion
    ):
        return "Optimize"

    else:
        return "Review"


channel_performance["Recommendation"] = (
    channel_performance.apply(classify_channel, axis=1)
)

print("\nCHANNEL INVESTMENT RECOMMENDATIONS:")
print(
    channel_performance[
        [
            "channel",
            "ROAS",
            "Conversion_Rate",
            "CPA",
            "Recommendation"
        ]
    ].sort_values(
        by="ROAS",
        ascending=False
    ).round(2).to_string(index=False)
)
# -----------------------------------
# 17. SAVE ANALYTICAL DATASET
# -----------------------------------

df.to_csv(
    "data/marketing_campaign_analysis.csv",
    index=False
)

print("\nAnalytical dataset saved successfully!")