SELECT
    SUM(impressions) AS total_impressions,
    SUM(clicks) AS total_clicks,
    SUM(conversions) AS total_conversions,
    ROUND(
        SUM(clicks) / SUM(impressions) * 100,
        2
    ) AS CTR,
    ROUND(
        SUM(conversions) / SUM(clicks) * 100,
        2
    ) AS conversion_rate
FROM marketing_campaigns;
SELECT
    month,
    ROUND(SUM(spend), 2) AS total_spend,
    ROUND(SUM(revenue), 2) AS total_revenue,
    SUM(conversions) AS total_conversions,
    ROUND(SUM(revenue) / SUM(spend), 2) AS ROAS
FROM marketing_campaigns
GROUP BY month
ORDER BY month;
SELECT
    campaign,
    SUM(spend) AS total_spend,
    SUM(revenue) AS total_revenue,
    SUM(conversions) AS total_conversions,
    ROUND(SUM(revenue) / SUM(spend), 2) AS ROAS
FROM marketing_campaigns
GROUP BY campaign
ORDER BY ROAS DESC
LIMIT 5;
SELECT
    channel,
    SUM(spend) AS total_spend,
    SUM(revenue) AS total_revenue,
    SUM(conversions) AS total_conversions,
    ROUND(SUM(revenue) / SUM(spend), 2) AS ROAS
FROM marketing_campaigns
GROUP BY channel
ORDER BY ROAS DESC;
USE marketing_analytics;
SELECT
    campaign,
    channel,
    COUNT(*) AS row_count
FROM marketing_campaigns
GROUP BY campaign, channel
ORDER BY row_count DESC;
SELECT COUNT(*) AS zero_conversion_rows
FROM marketing_campaigns
WHERE conversions = 0;
SELECT
    SUM(CPA IS NULL) AS missing_CPA,
    SUM(ROAS IS NULL) AS missing_ROAS,
    SUM(month IS NULL) AS missing_month
FROM marketing_campaigns;
SELECT
    COUNT(*) AS total_rows,
    SUM(date IS NULL) AS missing_date,
    SUM(campaign IS NULL) AS missing_campaign,
    SUM(channel IS NULL) AS missing_channel,
    SUM(impressions IS NULL) AS missing_impressions,
    SUM(clicks IS NULL) AS missing_clicks,
    SUM(spend IS NULL) AS missing_spend,
    SUM(conversions IS NULL) AS missing_conversions,
    SUM(revenue IS NULL) AS missing_revenue,
    SUM(CTR IS NULL) AS missing_CTR,
    SUM(CPC IS NULL) AS missing_CPC,
    SUM(Conversion_Rate IS NULL) AS missing_Conversion_Rate,
    SUM(CPA IS NULL) AS missing_CPA,
    SUM(ROAS IS NULL) AS missing_ROAS,
    SUM(month IS NULL) AS missing_month
FROM marketing_campaigns;
SELECT
    COUNT(*) AS total_rows,
    SUM(date IS NULL) AS missing_date,
    SUM(campaign IS NULL) AS missing_campaign,
    SUM(channel IS NULL) AS missing_channel,
    SUM(impressions IS NULL) AS missing_impressions,
    SUM(clicks IS NULL) AS missing_clicks,
    SUM(spend IS NULL) AS missing_spend,
    SUM(conversions IS NULL) AS missing_conversions,
    SUM(revenue IS NULL) AS missing_revenue
FROM marketing_campaigns;
SELECT *
FROM marketing_campaigns
LIMIT 5;
SELECT COUNT(*) AS total_rows
FROM marketing_campaigns;
USE marketing_analytics;
SELECT DATABASE();
USE marketing_analytics;
SET GLOBAL local_infile = 1;
SET GLOBAL local_infile = 1;
LOAD DATA LOCAL INFILE 'C:/Users/Prateeksha/OneDrive/Desktop/DataAnalyticsProject/data/clean/subscriptions_mysql.csv'
INTO TABLE subscriptions
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
USE saas_analytics;
SELECT COUNT(*) AS total_subscriptions
FROM subscriptions;
USE saas_analytics;
SELECT COUNT(*) AS total
FROM subscriptions;
SET SQL_SAFE_UPDATES = 1;
DELETE FROM subscriptions;
SET SQL_SAFE_UPDATES = 0;
DELETE FROM subscriptions
WHERE subscription_id IS NOT NULL;
USE saas_analytics;
DELETE FROM subscriptions;
USE saas_analytics;
SELECT COUNT(*) AS account_count
FROM accounts;
SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'saas_analytics'
AND TABLE_NAME = 'accounts'
ORDER BY ORDINAL_POSITION;
SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'saas_analytics'
AND TABLE_NAME = 'accounts'
ORDER BY ORDINAL_POSITION;
SELECT * FROM accounts LIMIT 5;
SELECT COUNT(*) AS account_count
FROM accounts;
USE saas_analytics;
SELECT COUNT(*) AS account_count
FROM accounts;
USE saas_analytics;
SELECT COUNT(*) AS account_count
FROM accounts;
SHOW TABLES;
CREATE TABLE churn_events (
    churn_event_id VARCHAR(50) PRIMARY KEY,
    account_id VARCHAR(50),
    churn_date DATE,
    reason_code VARCHAR(100),
    refund_amount_usd DECIMAL(10,2),
    preceding_upgrade_flag BOOLEAN,
    preceding_downgrade_flag BOOLEAN,
    is_reactivation BOOLEAN,
    feedback_text TEXT,

    FOREIGN KEY (account_id)
        REFERENCES accounts(account_id)
);
SHOW TABLES;
CREATE TABLE support_tickets (
    ticket_id VARCHAR(50) PRIMARY KEY,
    account_id VARCHAR(50),
    submitted_at DATETIME,
    closed_at DATETIME,
    resolution_time_hours DECIMAL(10,2),
    priority VARCHAR(50),
    first_response_time_minutes INT,
    satisfaction_score DECIMAL(5,2),
    escalation_flag BOOLEAN,

    FOREIGN KEY (account_id)
        REFERENCES accounts(account_id)
);
SHOW TABLES;
CREATE TABLE feature_usage (
    usage_id VARCHAR(50) PRIMARY KEY,
    subscription_id VARCHAR(50),
    usage_date DATE,
    feature_name VARCHAR(100),
    usage_count INT,
    usage_duration_secs INT,
    error_count INT,
    is_beta_feature BOOLEAN,

    FOREIGN KEY (subscription_id)
        REFERENCES subscriptions(subscription_id)
);
USE saas_analytics;
SHOW TABLES;
CREATE TABLE subscriptions (
    subscription_id VARCHAR(50) PRIMARY KEY,
    account_id VARCHAR(50),
    start_date DATE,
    end_date DATE,
    plan_tier VARCHAR(50),
    seats INT,
    mrr_amount INT,
    arr_amount INT,
    is_trial BOOLEAN,
    upgrade_flag BOOLEAN,
    downgrade_flag BOOLEAN,
    churn_flag BOOLEAN,
    billing_frequency VARCHAR(50),
    auto_renew_flag BOOLEAN,
    
    FOREIGN KEY (account_id) REFERENCES accounts(account_id)
);
USE saas_analytics;
SHOW TABLES;
CREATE TABLE accounts (
    account_id VARCHAR(50) PRIMARY KEY,
    account_name VARCHAR(255),
    industry VARCHAR(100),
    country VARCHAR(100),
    signup_date DATE,
    referral_source VARCHAR(100),
    plan_tier VARCHAR(50),
    seats INT,
    is_trial BOOLEAN,
    churn_flag BOOLEAN
);
USE saas_analytics;
CREATE TABLE accounts (
    account_id VARCHAR(50) PRIMARY KEY,
    account_name VARCHAR(255),
    industry VARCHAR(100),
    country VARCHAR(100),
    signup_date DATE,
    referral_source VARCHAR(100),
    plan_tier VARCHAR(50),
    seats INT,
    is_trial BOOLEAN,
    churn_flag BOOLEAN
);
USE saas_analytics;
CREATE TABLE accounts (
    account_id VARCHAR(50) PRIMARY KEY,
    account_name VARCHAR(255),
    industry VARCHAR(100),
    country VARCHAR(100),
    signup_date DATE,
    referral_source VARCHAR(100),
    plan_tier VARCHAR(50),
    seats INT,
    is_trial BOOLEAN,
    churn_flag BOOLEAN
);
USE saas_analytics;
SELECT DATABASE();
USE saas_analytics;
CREATE DATABASE saas_analytics;
SELECT USER(), VERSION();
SELECT
    SUM(impressions) AS total_impressions,
    SUM(clicks) AS total_clicks,
    SUM(conversions) AS total_conversions,
    ROUND(
        SUM(clicks) / SUM(impressions) * 100,
        2
    ) AS CTR,
    ROUND(
        SUM(conversions) / SUM(clicks) * 100,
        2
    ) AS conversion_rate
FROM marketing_campaigns;